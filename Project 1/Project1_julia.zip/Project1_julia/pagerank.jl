using MAT, SparseArrays
using LinearAlgebra, Plots

file = matread("ETH500.mat");
G = file["G"];
U = file["U"];

function pagerank(U, G)

    p = .85;

    n = size(G)[2];

    # out-degree
    c = vec(sum(G, dims=1));
    # in-degree
    r = vec(sum(G, dims=2));

    k = findall(!iszero, c);
    D = sparse(k, k, map(x -> 1/x, c[k]), n, n);

    e = ones(n, 1);
    sI = sparse(I, n, n);


    # Default implementation
    x = (sI - p * G * D) \ e;

    #Normalize
    x = x/sum(x);

    bar(x, lab="page ranking")
end