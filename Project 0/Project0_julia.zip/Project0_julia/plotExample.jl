using Plots

# Let's generate some points to plot
x = 1:10;
y = rand(10);

plot(x, y, show=true)
readline() # Just to wait for the plot to show up, might take about 10 seconds

# Installing prerequisites for Linux machines:
# sudo apt install libxt6 libxrender1 libxext6 libgl1-mesa-glx libqt5widgets5
